Source of images

tile1.jpg
Adapted (resized) from
https://www.flickr.com/photos/12739382@N04/3622156895/in/photostream/

wall1.jpg
https://www.flickr.com/photos/futurilla/4438589536

wall2.jpg
https://www.flickr.com/photos/futurilla/4438596322

wall3.jpg
https://www.flickr.com/photos/filterforge/8505868017

http://www.diytrade.com/china/pd/5006821/ceramic_floor_tile_600x600x9_2mm.html


Source of bump map textures
(brick-* = wall2*, fieldstone-*,layingrock-*)
https://svn.ict.usc.edu/svn_vh_public/trunk/lib/Panda3D/samples/Bump-Mapping/models/

